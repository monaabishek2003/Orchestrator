import http from 'http';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import express from 'express';
import cors from 'cors';
import agentsRouter from './routes/agents';
import { startStuckMonitor } from './jobs/stuck-monitor';
import { initSocket } from './socket';

// Run migrations so npx orchestrator-server works on a fresh machine
// DATABASE_URL is set as a side effect of importing agentsRouter → prisma.ts
try {
  execSync('npx prisma migrate deploy', {
    stdio: 'inherit',
    cwd: path.join(import.meta.dirname, '..'),
    env: { ...process.env },
  });
} catch {
  // Non-fatal — DB may already be up to date
}

const app = express();
const httpServer = http.createServer(app);
initSocket(httpServer);

app.use(cors());
app.use(express.json());
app.use(agentsRouter);

// Serve static dashboard only if public/ exists (production build)
const publicDir = path.join(import.meta.dirname, '..', 'public');
if (fs.existsSync(publicDir)) {
  app.use(express.static(publicDir));
  app.get('/{*splat}', (_req, res) => {
    res.sendFile(path.join(publicDir, 'index.html'));
  });
}

startStuckMonitor();

const port = Number(process.env.PORT) || 8000;
httpServer.listen(port, () => console.log(`Orchestrator server running on http://localhost:${port}`));
